import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { BookList }  from './app.booklist';
import {HttpModule} from '@angular/http';

import { AppComponent }  from './app.component';
import { SearchPipe }  from './filter';


@NgModule({
  imports:      [ BrowserModule,FormsModule,HttpModule ],
  declarations: [ AppComponent,BookList,SearchPipe],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
