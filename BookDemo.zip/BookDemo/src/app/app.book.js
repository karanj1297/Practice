"use strict";
var Book = (function () {
    function Book() {
    }
    return Book;
}());
exports.Book = Book;
