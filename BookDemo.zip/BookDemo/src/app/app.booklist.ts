import { Component, OnInit } from '@angular/core';
import { Book } from './app.book';
import { BookService } from './book.service'
@Component( {
    selector: '<my-component></my-component>',
    templateUrl: './app.component.html',
    providers: [BookService]
} )

export class BookList implements OnInit {

    books: Book[];


    search:string='';
    search1: string = '';
    search2: string = '';
    search3: string = '';
    search4: string = '';
    opt: string = '';


    toId(): void {
        this.opt = "1";
        this.search = this.search1;
    }
    toTitle(): void {
        this.opt = "2";
        this.search = this.search2;

    }
    toAuthor(): void {
        this.opt = "3";
        this.search = this.search3;

    }
    toYear(): void {
        this.opt = "4";
        this.search = this.search4;

    }
    constructor( private bookservice: BookService ) {

    }
    ngOnInit(): void {
        this.bookservice.getAllBook().subscribe(( bookData ) => this.books = bookData );
        
    }

}