import { Pipe, PipeTransform } from '@angular/core';
import { Book } from "./app.book";

@Pipe( {
    name: 'searchPipe'

} )
export class SearchPipe implements PipeTransform {
    transform( books: any, search: any, opt: string): any {
        if ( search == undefined ) return books;
        return books.filter( function( b1: any ) {
            console.log( b1 );

            if(opt=='1')
                {
                    return b1.id.toString().includes( search.toLowerCase());
                }
               
            
            else if(opt=='2'){
                
                return b1.title.toLowerCase().includes( search.toLowerCase() );
                
            }
                
                
            
            else if(opt=='3'){
                
                return b1.author.toLowerCase().includes( search.toLowerCase() );
                
            }
                
            
                
            
            else
                {
                    return b1.year.toString().includes( search.toLowerCase() );
                }

                
            
        } )
    }

}
