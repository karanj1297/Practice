

import { Component } from '@angular/core';
//import { Book } from './app.book';
@Component( {
    selector: 'my-app',
    template: '<my-component></my-component>'
} )
export class AppComponent {
    
    //name ="Welcome";
    
    
   /* search:string='';
    opt:string='';

    books: Book[] = [
        { id : 1, title: 'Java', author: "Karan", year: 2017},
        { id : 2, title: 'C', author: "Aditya", year: 2016 },
        { id : 3, title: 'C++', author: "Aniruddh", year: 2014 },
        { id : 4, title: 'Android', author: "Tejas", year: 2015 },

    ];
        */
    
    
}
