import { Injectable }      from '@angular/core';
import {Book} from './app.book';
import {Http,Response} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import "rxjs/add/operator/map"



@Injectable()
export class BookService {
    books:Book[];

    constructor(private http:Http) {
        
    }
        
        getAllBook():Observable<Book[]> 
    { return  this.http.get("booklist.json").
            map((response:Response)=><Book[]>response.json());
        }
    }
